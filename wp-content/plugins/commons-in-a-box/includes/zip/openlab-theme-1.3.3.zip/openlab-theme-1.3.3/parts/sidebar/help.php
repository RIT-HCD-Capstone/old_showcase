<div id="sidebar" class="sidebar col-sm-6 col-xs-24 type-help mobile-enabled" role="complementary">
	<div class="sidebar-wrapper">
		<?php get_sidebar( 'help' ); ?>
	</div>
</div>
